#include "presentation.h"
#include <QDebug>
#include "lecteurvue.h"
#include <QString>
#include <QList>

Presentation::Presentation(QObject *parent) :
    QObject{parent},
    idDiapo(0),
    idImage(0),
    tempsPasse(0)
{

    InfosDiaporama infosACharger;

    // Diaporama par défaut
    infosACharger.id = 0;
    infosACharger.titre = "Diaporama par defaut";
    infosACharger.vitesseDefilement = 2;
    pDiaporamas.push_back(infosACharger);

    // Diaporama de Pantxika
    infosACharger.id = 1;
    infosACharger.titre = "Diaporama Pantxika";
    infosACharger.vitesseDefilement = 2;
    pDiaporamas.push_back(infosACharger);

     // Diaporama de Thierry
    infosACharger.id = 2;
    infosACharger.titre = "Diaporama Thierry";
    infosACharger.vitesseDefilement = 4;
    pDiaporamas.push_back(infosACharger);

     // Diaporama de Yann
    infosACharger.id = 3;
    infosACharger.titre = "Diaporama Yann";
    infosACharger.vitesseDefilement = 2;
    pDiaporamas.push_back(infosACharger);

     // Diaporama de Manu
    infosACharger.id = 4;
    infosACharger.titre = "Diaporama Manu";
    infosACharger.vitesseDefilement = 1;
    pDiaporamas.push_back(infosACharger);

    connect(timer, SIGNAL(timeout()), this, SLOT(tic()));
}

Modele *Presentation::getModele()
{
    return _leModele;
}

LecteurVue *Presentation::getVue()
{
    return _laVue;
}

int Presentation::getIdDiapo()
{
    return idDiapo;
}

int Presentation::getIdImage()
{
    return idImage;
}

void Presentation::setModele(Modele *m)
{
    _leModele = m;
}

void Presentation::setVue(LecteurVue *v)
{
    _laVue = v;
}

void Presentation::setIdDiapo(unsigned int i)
{
    idDiapo = i;
}

void Presentation::setIdImage(unsigned int i)
{
    idImage = i;
}

//-------------------------------------------

void Presentation::demanderAvancer()
{
    timer->stop();
    QList<QString> liste;

    liste = _leModele->avancer(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));

    idImage = QString(liste[3]).toInt() - 1;
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderReculer()
{
    timer->stop();
    QList<QString> liste;

    liste = _leModele->reculer(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));

    idImage = QString(liste[3]).toInt() - 1;
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderQuitter()
{
    _leModele->quitter();
}

void Presentation::demanderLancerDiapo()
{
    tempsPasse = 0;
    dureeImage = pDiaporamas[idDiapo - 1].vitesseDefilement;
    timer->start(1000);
}

void Presentation::demanderArreterDiapo()
{
    timer->stop();
}

void Presentation::demanderAProposDe()
{
    timer->stop();
    _laVue->hide();
    _leModele->aProposDe();
    demanderAvancer();
    demanderReculer();
    _laVue->show();
}

void Presentation::demanderChargerDiapo()
{
    timer->stop();
    //Mais qu'est ce donc
}

void Presentation::demanderEnleverDiapo()
{
    timer->stop();
    //juste clear
    QList<QString> liste;

    liste = _leModele->enlever();
    liste.append(QString::fromStdString("Titre du diapo"));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderVitesseDefilement()
{
    timer->stop();
    //plus tard
}

void Presentation::demanderDiapoPantxika()
{
    timer->stop();
    idDiapo = 1;
    idImage = 0;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderDiapoThierry()
{
    timer->stop();
    idDiapo = 2;
    idImage = 0;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderDiapoYann()
{
    timer->stop();
    idDiapo = 3;
    idImage = 0;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderDiapoManu()
{
    timer->stop();
    idDiapo = 4;
    idImage = 0;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::avancerAvecTimer()
{
    QList<QString> liste;

    liste = _leModele->avancer(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));
    idImage = QString(liste[3]).toInt() - 1;
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::tic()
{
    tempsPasse++;
    qDebug() << "temps passé = " << tempsPasse << Qt::endl;
    if (tempsPasse == dureeImage)
    {
        avancerAvecTimer();
        dureeImage = dureeImage + pDiaporamas[idDiapo - 1].vitesseDefilement;
    }
}
