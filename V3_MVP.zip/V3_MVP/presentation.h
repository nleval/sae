#ifndef PRESENTATION_H
#define PRESENTATION_H

#include <QObject>
#include "modele.h"
#include "diaporama.h"

class LecteurVue;


class Presentation : public QObject
{
    Q_OBJECT

    struct InfosDiaporama {
        unsigned int id;    // identifiant du diaporama dans la BD
        string titre;       // titre du diaporama
        unsigned int vitesseDefilement;
    };

    typedef vector<InfosDiaporama> Diaporamas;

public:
    explicit Presentation(QObject *parent = nullptr);

public:
    Modele* getModele();
    LecteurVue* getVue();
    void setModele(Modele *m);
    void setVue(LecteurVue *v);
    void demandeAvancer();
    void demandeReculer();
    void demandeQuitter();
    void demandeLancerDiapo();
    void demandeArreterDiapo();
    void demandeAProposDe();
    void demandeChangerDiapo();
    void demandeChargerDiapo();
    void demandeEnleverDiapo();
    void demandeVitesseDefilement();

private:
    Modele *_leModele; // pointeur sur le modèle
    LecteurVue *_laVue; // pointeur sur la vue
    Diaporamas _leDiaporama; // vecteurs des infos sur les diaporamas

};

#endif // PRESENTATION_H
