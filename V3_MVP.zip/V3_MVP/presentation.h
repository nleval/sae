#ifndef PRESENTATION_H
#define PRESENTATION_H

#include <QObject>
#include "modele.h"
#include "diaporama.h"

class LecteurVue;

class Presentation : public QObject
{
    Q_OBJECT
public:
    explicit Presentation(QObject *parent = nullptr);

public:
    Modele* getModele();
    LecteurVue* getVue();
    void setModele(Modele *m);
    void setVue(LecteurVue *v);
    void demandeAvancer();
    void demandeReculer();
    void demandeQuitter();
    void demandeLancerDiapo();
    void demandeArreterDiapo();
    void demandeAProposDe();
    void demandeChangerDiapo();
    void demandeChargerDiapo();
    void demandeEnleverDiapo();
    void demandeVitesseDefilement();

private:
    Modele *_leModele; // pointeur sur le modèle
    LecteurVue *_laVue; // pointeur sur la vue
    Diaporama *_leDiaporama; // pointeur sur le diaporama

};

#endif // PRESENTATION_H
