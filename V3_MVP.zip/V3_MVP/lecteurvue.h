#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QWidget>
#include <QMainWindow>
#include <QAction>
#include "modele.h"
#include "diaporama.h"
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui { class LecteurVue; }
QT_END_NAMESPACE

class Presentation;

class LecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    LecteurVue(QWidget *parent = nullptr);
    ~LecteurVue();
    // ordre de la Présentation de MAJ de l’interface en fonction de l’état du modèle
    void majInterface (Modele::UnMode u, Modele::UneAction a);
    // gestion des attributs privés
    Presentation* getPresentation() ;
    void setPresentation (Presentation * p) ;

private:
    Ui::LecteurVue *ui;
    Presentation* _laPresentation;
    Modele* _leModele;

private slots:
    void demandeAvancer();
    void demandeReculer();
    void demandeQuitter();
    void demandeLancerDiapo();
    void demandeArreterDiapo();
    void demandeAProposDe();
    void demandeChangerDiapo();
    void demandeChargerDiapo();
    void demandeEnleverDiapo();
    void demandeVitesseDefilement();
};
#endif // LECTEURVUE_H
