#include "presentation.h"
#include "lecteurvue.h"
#include <iostream>
using namespace std;

Presentation::Presentation(QObject *parent)
    : QObject{parent}
{

}

Modele *Presentation::getModele()
{
    return _leModele;
}

LecteurVue *Presentation::getVue()
{
    return _laVue;
}

void Presentation::setModele(Modele *m)
{
    _leModele = m;
}

void Presentation::setVue(LecteurVue *v)
{
    _laVue = v;
}

void Presentation::demandeAvancer()
{
    _leModele->avancer();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeReculer()
{
    _leModele->reculer();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeQuitter()
{
    _leModele->quitter();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeLancerDiapo()
{
    _leModele->lancerDiapo();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeArreterDiapo()
{
    _leModele->arreterDiapo();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeAProposDe()
{
    _laVue->hide();
    _leModele->aProposDe();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
    _laVue->show();
}

void Presentation::demandeChangerDiapo()
{
    unsigned int pId=_leModele->getIdDiaporama();
    string pTitre=_leDiaporama->getTitre();
    unsigned int pVitesse=_leDiaporama->getVitesseDefilement();
    _leModele->changerDiapo(pId, pTitre, pVitesse);
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeChargerDiapo()
{
    _leModele->chargerDiapo();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeEnleverDiapo()
{
    _leModele->enleverDiapo();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeVitesseDefilement()
{
    _leModele->vitesseDefilement();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}
