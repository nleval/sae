#include "presentation.h"
#include "lecteurvue.h"
#include <iostream>
using namespace std;

Presentation::Presentation(QObject *parent)
    : QObject{parent}
{
    InfosDiaporama infosACharger;

    // Diaporama de Pantxika
    infosACharger.id = 1;
    infosACharger.titre = "Diaporama Pantxika";
    infosACharger.vitesseDefilement = 2;
    _leDiaporama.push_back(infosACharger);

    // Diaporama de Thierry
    infosACharger.id = 2;
    infosACharger.titre = "Diaporama Thierry";
    infosACharger.vitesseDefilement = 4;
    _leDiaporama.push_back(infosACharger);

    // Diaporama de Yann
    infosACharger.id = 3;
    infosACharger.titre = "Diaporama Yann";
    infosACharger.vitesseDefilement = 2;
    _leDiaporama.push_back(infosACharger);

    // Diaporama de Manu
    infosACharger.id = 4;
    infosACharger.titre = "Diaporama Manu";
    infosACharger.vitesseDefilement = 1;
    _leDiaporama.push_back(infosACharger);

}

Modele *Presentation::getModele()
{
    return _leModele;
}

LecteurVue *Presentation::getVue()
{
    return _laVue;
}

void Presentation::setModele(Modele *m)
{
    _leModele = m;
}

void Presentation::setVue(LecteurVue *v)
{
    _laVue = v;
}

void Presentation::demandeAvancer()
{
    _leModele->avancer();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeReculer()
{
    _leModele->reculer();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeQuitter()
{
    _leModele->quitter();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeLancerDiapo()
{
    _leModele->lancerDiapo();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeArreterDiapo()
{
    _leModele->arreterDiapo();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeAProposDe()
{
    _laVue->hide();
    _leModele->aProposDe();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
    _laVue->show();
}

void Presentation::demandeChangerDiapo()
{
    /* CORRIGER (c'est cassé)
        unsigned int pId=_leModele->getIdDiaporama();
        string pTitre=_leModele->getDiaporama()->getTitre();
        unsigned int pVitesse=_leModele->getDiaporama()->getVitesseDefilement();
        _leModele->changerDiapo(pId, pTitre, pVitesse);
        _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
        */

}

void Presentation::demandeChargerDiapo()
{
    /* CORRIGER (c'est cassé)
    _leModele->chargerDiapo();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
    */
}

void Presentation::demandeEnleverDiapo()
{
    _leModele->enleverDiapo();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}

void Presentation::demandeVitesseDefilement()
{
    _leModele->vitesseDefilement();
    _laVue->majInterface(_leModele->getMode(), _leModele->getAction());
}
