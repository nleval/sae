#ifndef VITESSEDEFIL_H
#define VITESSEDEFIL_H

#include <QDialog>

namespace Ui {
class VitesseDefil;
}

class VitesseDefil : public QDialog
{
    Q_OBJECT

public:
    explicit VitesseDefil(QWidget *parent = nullptr);
    ~VitesseDefil();

    int getVitesse();

private:
    Ui::VitesseDefil *ui;
    int vitesse;

private slots:
    void valider();
};

#endif // VITESSEDEFIL_H
