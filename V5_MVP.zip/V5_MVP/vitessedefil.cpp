#include "vitessedefil.h"
#include "ui_vitessedefil.h"

VitesseDefil::VitesseDefil(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::VitesseDefil)
{
    ui->setupUi(this);
    setWindowTitle("Vitesse de défilement");

    connect(ui->bValider, SIGNAL(clicked()), this, SLOT(valider()));
}

VitesseDefil::~VitesseDefil()
{
    delete ui;
}

int VitesseDefil::getVitesse()
{
    return vitesse;
}

void VitesseDefil::valider()
{
    vitesse = ui->LiEdVitesse->text().toInt();
    this->hide();
}
