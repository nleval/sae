#include "modele.h"
#include <QString>
#include "dialog.h"
#include <QCoreApplication>
#include "vitessedefil.h"

Modele::Modele(QObject *parent)
    : QObject{parent}
{}

Modele::UnEtat Modele::getEtat()
{
    return _etat;
}

Diaporama Modele::getDiapo()
{
    return diapo;
}

void Modele::setDiapo(Diaporama d)
{
    diapo = d;
}

QList<QString> Modele::avancer(unsigned int idDiapo, unsigned int idImage)
{
    diapo.setId(idDiapo);
    diapo.vider();
    diapo.charger();

    if (idImage == diapo.nbImages() - 1)
    {
        idImage = 0;
    }
    else
    {
        idImage += 1;
    }

    QList<QString> liste;
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getTitre()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getCategorie()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getChemin()));
    liste.append(QString::number(idImage + 1));

    _etat = Modele::change;

    return liste;
}

QList<QString> Modele::reculer(unsigned int idDiapo, unsigned int idImage)
{
    diapo.setId(idDiapo);
    diapo.vider();
    diapo.charger();

    if (idImage == 0)
    {
        idImage = diapo.nbImages() - 1;
    }
    else
    {
        idImage -= 1;
    }

    QList<QString> liste;
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getTitre()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getCategorie()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getChemin()));
    liste.append(QString::number(idImage + 1));

    _etat = Modele::change;

    return liste;
}

void Modele::aProposDe()
{
    Dialog * maDlg= new Dialog(nullptr);
    maDlg->exec();
}

void Modele::quitter()
{
    QCoreApplication::quit();
}

QList<QString> Modele::changerDiapo(unsigned int idDiapo, unsigned int idImage)
{
    diapo.setId(idDiapo);
    diapo.vider();
    diapo.charger();

    QList<QString> liste;
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getTitre()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getCategorie()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getChemin()));
    liste.append(QString::number(idImage + 1));

    _etat = Modele::change;

    return liste;
}

QList<QString> Modele::enlever()
{
    QList<QString> liste;
    liste.append(QString::fromStdString("Titre de l'image"));
    liste.append(QString::fromStdString("Categorie"));
    liste.append(QString::fromStdString("Chemin d'acces"));
    liste.append(QString::fromStdString("nb images"));

    _etat = Modele::change;

    return liste;
}

int Modele::vitesseDefil()
{
    VitesseDefil * maVitDef= new VitesseDefil(nullptr);
    maVitDef->exec();
    return maVitDef->getVitesse();
}
