#include "lecteurvue.h"
#include "ui_lecteurvue.h"
#include <QDebug>
#include "presentation.h"

LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{
    ui->setupUi(this);

    connect(ui->bAvancer, SIGNAL(clicked()), this, SLOT(avancer()));
    connect(ui->bReculer, SIGNAL(clicked()), this, SLOT(reculer()));
    connect(ui->actionQuitter, SIGNAL(triggered()), this, SLOT(quitter()));
    connect(ui->bLancerDiapo, SIGNAL(clicked()), this, SLOT(lancerDiapo()));
    connect(ui->bArretDiapo, SIGNAL(clicked()), this, SLOT(arreterDiapo()));
    connect(ui->actionA_propos_de, SIGNAL(triggered()), this, SLOT(aProposDe()));
    connect(ui->actionCharger_diaporama, SIGNAL(triggered()), this, SLOT(chargerDiapo()));
    connect(ui->actionEnlever_diaporama, SIGNAL(triggered()), this, SLOT(enleverDiapo()));
    connect(ui->actionVitesse_de_defilement, SIGNAL(triggered()), this, SLOT(vitesseDefilement()));
    connect(ui->actionManu, SIGNAL(triggered()), this, SLOT (diapoManu()));
    connect(ui->actionPantxika, SIGNAL(triggered()), this, SLOT (diapoPantxika()));
    connect(ui->actionThierry, SIGNAL(triggered()), this, SLOT (diapoThierry()));
    connect(ui->actionYann, SIGNAL(triggered()), this, SLOT (diapoYann()));
}

LecteurVue::~LecteurVue()
{
    delete ui;
}

void LecteurVue::majInterface(Modele::UnEtat e, QList<QString> l)
{
    switch(e)
    {
        case Modele::change :
        {
            ui->etIntituleImage->setText(l[0]);             //titre image
            ui->etFiltreType->setText(l[1]);                //categorie
            ui->etTitreDiapo->setPixmap(QPixmap((l[2])));   //chemin
            ui->etImage->setText(l[3]);                     //nb image
            ui->groupBox->setTitle(l[4]);                   //titre diapo
        }
        case Modele::vide :
        {

        }
    }
}

Presentation *LecteurVue::getPresentation()
{
    return _laPresentation;
}

void LecteurVue::setPresentation(Presentation *p)
{
    _laPresentation = p;
}

void LecteurVue::avancer()
{
    ui->bArretDiapo->setDisabled(true);
    getPresentation()->demanderAvancer();
}

void LecteurVue::reculer()
{
    ui->bArretDiapo->setDisabled(true);
    getPresentation()->demanderReculer();
}

void LecteurVue::quitter()
{
    ui->bArretDiapo->setDisabled(true);
    getPresentation()->demanderQuitter();
}

void LecteurVue::lancerDiapo()
{
    ui->bArretDiapo->setDisabled(false);
    getPresentation()->demanderLancerDiapo();
}

void LecteurVue::arreterDiapo()
{
    ui->bArretDiapo->setDisabled(true);
    getPresentation()->demanderArreterDiapo();
}

void LecteurVue::aProposDe()
{
    ui->bArretDiapo->setDisabled(true);
    getPresentation()->demanderAProposDe();
}

void LecteurVue::chargerDiapo()
{
    ui->bArretDiapo->setDisabled(true);
    ui->actionManu->setDisabled(false);
    ui->actionPantxika->setDisabled(false);
    ui->actionThierry->setDisabled(false);
    ui->actionYann->setDisabled(false);
    ui->bAvancer->setDisabled(false);
    ui->bReculer->setDisabled(false);
    ui->bLancerDiapo->setDisabled(false);
    ui->actionVitesse_de_defilement->setDisabled(false);
    getPresentation()->demanderChargerDiapo();
}

void LecteurVue::enleverDiapo()
{
    ui->bArretDiapo->setDisabled(true);
    ui->actionManu->setDisabled(true);
    ui->actionPantxika->setDisabled(true);
    ui->actionThierry->setDisabled(true);
    ui->actionYann->setDisabled(true);
    ui->bAvancer->setDisabled(true);
    ui->bReculer->setDisabled(true);
    ui->bLancerDiapo->setDisabled(true);
    ui->actionVitesse_de_defilement->setDisabled(true);
    getPresentation()->demanderEnleverDiapo();
}

void LecteurVue::vitesseDefilement()
{
    ui->bArretDiapo->setDisabled(true);
    getPresentation()->demanderVitesseDefilement();
}

void LecteurVue::diapoPantxika()
{
    ui->bArretDiapo->setDisabled(true);
    getPresentation()->demanderDiapoPantxika();
}

void LecteurVue::diapoManu()
{
    ui->bArretDiapo->setDisabled(true);
    getPresentation()->demanderDiapoManu();
}

void LecteurVue::diapoYann()
{
    ui->bArretDiapo->setDisabled(true);
    getPresentation()->demanderDiapoYann();
}

void LecteurVue::diapoThierry()
{
    ui->bArretDiapo->setDisabled(true);
    getPresentation()->demanderDiapoThierry();
}
