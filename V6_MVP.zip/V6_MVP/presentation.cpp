#include "presentation.h"
#include <QDebug>
#include "lecteurvue.h"
#include <QList>

Presentation::Presentation(QObject *parent) :
    QObject{parent},
    idImage(0),
    dureeImage(2),
    tempsPasse(0)
{
    connect(timer, SIGNAL(timeout()), this, SLOT(tic()));
}

Modele *Presentation::getModele()
{
    return _leModele;
}

LecteurVue *Presentation::getVue()
{
    return _laVue;
}

int Presentation::getIdImage()
{
    return idImage;
}

void Presentation::setModele(Modele *m)
{
    _leModele = m;
}

void Presentation::setVue(LecteurVue *v)
{
    _laVue = v;
}

void Presentation::setIdImage(unsigned int i)
{
    idImage = i;
}

//-------------------------------------------

void Presentation::demanderAvancer()
{
    timer->stop();
    QList<QString> liste;

    liste = _leModele->avancer(idImage);

    idImage = QString(liste[3]).toInt();
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderReculer()
{
    timer->stop();
    QList<QString> liste;

    liste = _leModele->reculer(idImage);

    idImage = QString(liste[3]).toInt();
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderQuitter()
{
    _leModele->quitter();
}

void Presentation::demanderLancerDiapo()
{
    tempsPasse = 0;
    timer->start(1000);
    qDebug() << "temps passé = " << tempsPasse << Qt::endl;
}

void Presentation::demanderArreterDiapo()
{
    timer->stop();
}

void Presentation::demanderAProposDe()
{
    timer->stop();
    _laVue->hide();
    _leModele->aProposDe();
    demanderAvancer();
    demanderReculer();
    _laVue->show();
}

void Presentation::demanderChargerDiapo()
{

}

void Presentation::demanderEnleverDiapo()
{
    timer->stop();
    QList<QString> liste;

    liste = _leModele->enlever();
    liste.append(QString::fromStdString("Titre du diapo"));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderVitesseDefilement()
{
    timer->stop();
    _laVue->hide();
    dureeImage = _leModele->vitesseDefil();
    demanderAvancer();
    demanderReculer();
    _laVue->show();
}

void Presentation::avancerAvecTimer()
{
    QList<QString> liste;

    liste = _leModele->avancer(idImage);

    idImage = QString(liste[3]).toInt();
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::tic()
{
    tempsPasse++;
    qDebug() << "temps passé = " << tempsPasse << Qt::endl;
    if (tempsPasse == dureeImage)
    {
        avancerAvecTimer();
        tempsPasse = 0;
        qDebug() << Qt::endl << "temps passé = " << tempsPasse << Qt::endl;
    }
}
