#include "presentation.h"
#include <QDebug>
#include "lecteurvue.h"
#include <QString>
#include <QList>
#include "database.h"
#include "qsqlquery.h"

Presentation::Presentation(QObject *parent) :
    QObject{parent},
    idDiapo(0),
    idImage(0),
    tempsPasse(0)
{
    db = new Database();
    db->openDataBase();

    InfosDiaporama infosACharger;
    QSqlQuery query;

    // Diaporama par défaut
    infosACharger.id = 0;
    infosACharger.titre = "Diaporama par defaut";
    infosACharger.vitesseDefilement = 2;
    pDiaporamas.push_back(infosACharger);

    // Diaporama de Pantxika
    query.exec("SELECT idDiaporama, titreDiaporama, vitesseDefilement "
                                      "FROM Diaporamas "
                                      "WHERE idDiaporama = 1");
    for(int i = 0; query.next(); i++)
    {
     qDebug() << i << query.value(0) << query.value(1) << query.value(2) << Qt::endl;
     infosACharger.id = query.value(0).toInt();
     //infosACharger.titre = query.value(1).toString();
     infosACharger.vitesseDefilement = query.value(2).toInt();
    }
    pDiaporamas.push_back(infosACharger);
    /*infosACharger.id = query.exec("SELECT idDiaporama, titreDiaporama, vitesseDefilement "
                                  "FROM Diaporamas "
                                  "WHERE idDiaporama = 1");
    qDebug() << "id diapo : " << infosACharger.id;
    infosACharger.titre = query.exec("SELECT  "
                                     "FROM Diaporamas "
                                     "WHERE idDiaporama = 1");
    infosACharger.vitesseDefilement = query.exec("SELECT  "
                                                 "FROM Diaporamas "
                                                 "WHERE idDiaporama = 1");
    qDebug() << "vitesse defil : " << infosACharger.vitesseDefilement;
    pDiaporamas.push_back(infosACharger);*/

     // Diaporama de Thierry
    query.exec("SELECT idDiaporama, titreDiaporama, vitesseDefilement "
                                      "FROM Diaporamas "
                                      "WHERE idDiaporama = 2");
    for(int i = 0; query.next(); i++)
    {
     qDebug() << i << query.value(0) << query.value(1) << query.value(2) << Qt::endl;
     infosACharger.id = query.value(0).toInt();
     //infosACharger.titre = query.value(1).toString();
     infosACharger.vitesseDefilement = query.value(2).toInt();
    }
    pDiaporamas.push_back(infosACharger);
    /*infosACharger.id = query.exec("SELECT idDiaporama "
                                  "FROM Diaporamas "
                                  "WHERE idDiaporama = 2");
    qDebug() << "id diapo : " << infosACharger.id;
    infosACharger.titre = query.exec("SELECT titreDiaporama "
                                     "FROM Diaporamas "
                                     "WHERE idDiaporama = 2");
    infosACharger.vitesseDefilement = query.exec("SELECT vitesseDefilement "
                                                 "FROM Diaporamas "
                                                 "WHERE idDiaporama = 2");
    qDebug() << "vitesse defil : " << infosACharger.vitesseDefilement;
    pDiaporamas.push_back(infosACharger);*/

     // Diaporama de Yann
    query.exec("SELECT idDiaporama, titreDiaporama, vitesseDefilement "
                                      "FROM Diaporamas "
                                      "WHERE idDiaporama = 3");
    for(int i = 0; query.next(); i++)
    {
     qDebug() << i << query.value(0) << query.value(1) << query.value(2) << Qt::endl;
     infosACharger.id = query.value(0).toInt();
     //infosACharger.titre = query.value(1).toString();
     infosACharger.vitesseDefilement = query.value(2).toInt();
    }
    pDiaporamas.push_back(infosACharger);
    /*infosACharger.id = query.exec("SELECT idDiaporama "
                                  "FROM Diaporamas "
                                  "WHERE idDiaporama = 3");
    qDebug() << "id diapo : " << infosACharger.id;
    infosACharger.titre = query.exec("SELECT titreDiaporama "
                                     "FROM Diaporamas "
                                     "WHERE idDiaporama = 3");
    infosACharger.vitesseDefilement = query.exec("SELECT vitesseDefilement "
                                                 "FROM Diaporamas "
                                                 "WHERE idDiaporama = 3");
    qDebug() << "vitesse defil : " << infosACharger.vitesseDefilement;
    pDiaporamas.push_back(infosACharger);*/

     // Diaporama de Manu
    query.exec("SELECT idDiaporama, titreDiaporama, vitesseDefilement "
                                      "FROM Diaporamas "
                                      "WHERE idDiaporama = 4");
    for(int i = 0; query.next(); i++)
    {
     qDebug() << i << query.value(0) << query.value(1) << query.value(2) << Qt::endl;
     infosACharger.id = query.value(0).toInt();
     //infosACharger.titre = query.value(1).toString();
     infosACharger.vitesseDefilement = query.value(2).toInt();
    }
    pDiaporamas.push_back(infosACharger);
    /*infosACharger.id = query.exec("SELECT idDiaporama "
                                  "FROM Diaporamas "
                                  "WHERE idDiaporama = 4");
    qDebug() << "id diapo : " << infosACharger.id;
    infosACharger.titre = query.exec("SELECT titreDiaporama "
                                     "FROM Diaporamas "
                                     "WHERE idDiaporama = 4");
    infosACharger.vitesseDefilement = query.exec("SELECT vitesseDefilement "
                                                 "FROM Diaporamas "
                                                 "WHERE idDiaporama = 4");
    qDebug() << "vitesse defil : " << infosACharger.vitesseDefilement;
    pDiaporamas.push_back(infosACharger);*/

    connect(timer, SIGNAL(timeout()), this, SLOT(tic()));

    db->closeDataBase();
}

Modele *Presentation::getModele()
{
    return _leModele;
}

LecteurVue *Presentation::getVue()
{
    return _laVue;
}

int Presentation::getIdDiapo()
{
    return idDiapo;
}

int Presentation::getIdImage()
{
    return idImage;
}

void Presentation::setModele(Modele *m)
{
    _leModele = m;
}

void Presentation::setVue(LecteurVue *v)
{
    _laVue = v;
}

void Presentation::setIdDiapo(unsigned int i)
{
    idDiapo = i;
}

void Presentation::setIdImage(unsigned int i)
{
    idImage = i;
}

//-------------------------------------------

void Presentation::demanderAvancer()
{
    timer->stop();
    QList<QString> liste;

    liste = _leModele->avancer(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));

    idImage = QString(liste[3]).toInt() - 1;
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderReculer()
{
    timer->stop();
    QList<QString> liste;

    liste = _leModele->reculer(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));

    idImage = QString(liste[3]).toInt() - 1;
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderQuitter()
{
    _leModele->quitter();
}

void Presentation::demanderLancerDiapo()
{
    tempsPasse = 0;
    dureeImage = pDiaporamas[idDiapo].vitesseDefilement;
    timer->start(1000);
}

void Presentation::demanderArreterDiapo()
{
    timer->stop();
}

void Presentation::demanderAProposDe()
{
    timer->stop();
    _laVue->hide();
    _leModele->aProposDe();
    demanderAvancer();
    demanderReculer();
    _laVue->show();
}

void Presentation::demanderChargerDiapo()
{
    timer->stop();
    idDiapo = 0;
    idImage = 0;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderEnleverDiapo()
{
    timer->stop();
    //juste clear
    QList<QString> liste;

    liste = _leModele->enlever();
    liste.append(QString::fromStdString("Titre du diapo"));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderVitesseDefilement()
{
    timer->stop();
    _laVue->hide();
    pDiaporamas[idDiapo].vitesseDefilement = _leModele->vitesseDefil();
    demanderAvancer();
    demanderReculer();
    _laVue->show();
}

void Presentation::demanderDiapoPantxika()
{
    timer->stop();
    idDiapo = 1;
    idImage = 0;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderDiapoThierry()
{
    timer->stop();
    idDiapo = 2;
    idImage = 0;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderDiapoYann()
{
    timer->stop();
    idDiapo = 3;
    idImage = 0;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderDiapoManu()
{
    timer->stop();
    idDiapo = 4;
    idImage = 0;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::avancerAvecTimer()
{
    QList<QString> liste;

    liste = _leModele->avancer(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo].titre));
    idImage = QString(liste[3]).toInt() - 1;
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::tic()
{
    tempsPasse++;
    qDebug() << "temps passé = " << tempsPasse << Qt::endl;
    if (tempsPasse == dureeImage)
    {
        avancerAvecTimer();
        dureeImage = dureeImage + pDiaporamas[idDiapo].vitesseDefilement;
    }
}
