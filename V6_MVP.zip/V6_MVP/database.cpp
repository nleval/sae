#include "database.h"
#include "qdebug.h"
#include "qsqlquery.h"
#include "QSqlError"

Database::Database()
{

}

bool Database::openDataBase()
{
    mydb = QSqlDatabase::addDatabase(CONNECT_TYPE);
    mydb.setDatabaseName(DATABASE_NAME);
    return mydb.open();
}

void Database::closeDataBase()
{
    mydb.close();
}
