#include "database.h"
#include "qdebug.h"
#include "qsqlquery.h"
#include "QSqlError"

Database::Database()
{
    mydb = QSqlDatabase::addDatabase(CONNECT_TYPE);
    mydb.setDatabaseName(DATABASE_NAME);
}

bool Database::openDataBase()
{
    if(!mydb.open())
    {
        qDebug() << "Error: Unable to open database" << mydb.lastError();
        return false;
    }
    qDebug() << "Database opened successfully";
    return true;
}
void Database::closeDataBase()
{
    mydb.close();
}
