#ifndef MODELE_H
#define MODELE_H

#include <QObject>
#include "database.h"

class Modele : public QObject
{
    Q_OBJECT
public:
    enum UnEtat {vide, change};
    explicit Modele(QObject *parent = nullptr);
    UnEtat getEtat();
    void setEtat(UnEtat);

    QList<QString> avancer(int);
    QList<QString> reculer(int);
    void aProposDe();
    void quitter();
    QList<QString> changerDiapo(unsigned int, unsigned int);
    QList<QString> enlever();
    int vitesseDefil();

private:
    UnEtat _etat;
    Database *db;

signals:
};

#endif // MODELE_H
