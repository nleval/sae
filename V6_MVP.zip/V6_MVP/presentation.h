#ifndef PRESENTATION_H
#define PRESENTATION_H

#include "modele.h"
#include <QObject>
#include <QVector>
#include "QTimer"

class LecteurVue;
class Presentation : public QObject
{
    Q_OBJECT

    struct InfosDiaporama {
        unsigned int id;    // identifiant du diaporama dans la BD
        string titre;       // titre du diaporama
        unsigned int vitesseDefilement;
    };

    typedef vector<InfosDiaporama> Diaporamas;

public:
    explicit Presentation(QObject *parent = nullptr);
    Modele* getModele();
    LecteurVue* getVue();
    int getIdDiapo();
    int getIdImage();

    void setModele(Modele *m);
    void setVue(LecteurVue *v);
    void setIdDiapo(unsigned int);
    void setIdImage(unsigned int);

    void demanderAvancer();
    void demanderReculer();
    void demanderQuitter();
    void demanderLancerDiapo();
    void demanderArreterDiapo();
    void demanderAProposDe();
    void demanderChargerDiapo();
    void demanderEnleverDiapo();
    void demanderVitesseDefilement();
    void demanderDiapoPantxika();
    void demanderDiapoThierry();
    void demanderDiapoYann();
    void demanderDiapoManu();
    void avancerAvecTimer();

private:
    Modele* _leModele;
    LecteurVue* _laVue;
    Diaporamas pDiaporamas;
    unsigned int idDiapo;
    unsigned int idImage;
    unsigned short int dureeImage;
    unsigned short int tempsPasse = 0;
    QTimer *timer = new QTimer(this);
    Database *db;

private slots:
    void tic();

signals:
};

#endif // PRESENTATION_H
