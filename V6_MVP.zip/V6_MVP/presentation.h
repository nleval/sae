#ifndef PRESENTATION_H
#define PRESENTATION_H

#include "modele.h"
#include <QObject>
#include <QVector>
#include "QTimer"
#include <QString>
#include <iostream>
using namespace std;

class LecteurVue;
class Presentation : public QObject
{
    Q_OBJECT

    struct InfosDiaporama {
        unsigned int id;    // identifiant du diaporama dans la BD
        std::string titre;       // titre du diaporama
        unsigned int vitesseDefilement;
    };

    typedef vector<InfosDiaporama> Diaporamas;

public:
    explicit Presentation(QObject *parent = nullptr);
    Modele* getModele();
    LecteurVue* getVue();
    int getIdImage();

    void setModele(Modele *m);
    void setVue(LecteurVue *v);
    void setIdImage(unsigned int);

    void demanderAvancer();
    void demanderReculer();
    void demanderQuitter();
    void demanderLancerDiapo();
    void demanderArreterDiapo();
    void demanderAProposDe();
    void demanderChargerDiapo();
    void demanderEnleverDiapo();
    void demanderVitesseDefilement();
    void avancerAvecTimer();

private:
    Modele* _leModele;
    LecteurVue* _laVue;
    int idImage;
    unsigned short int dureeImage;
    unsigned short int tempsPasse;
    QTimer *timer = new QTimer(this);

private slots:
    void tic();

signals:
};

#endif // PRESENTATION_H
