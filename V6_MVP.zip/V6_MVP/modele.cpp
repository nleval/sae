#include "modele.h"
#include <QString>
#include "QtSql/qsqlquery.h"
#include "dialog.h"
#include <QCoreApplication>
#include "qsqlerror.h"
#include "vitessedefil.h"
#include "database.h"
#include "qsqlquery.h"

Modele::Modele(QObject *parent)
    : QObject{parent}
{
    db = new Database();
    if (db->openDataBase())
    {
        QSqlQuery query;
        if (query.exec("SELECT COUNT(idphoto) FROM Diapos")) {
            while (query.next())
            {
                qDebug() << query.value(0).toString() << " constructeur" << Qt::endl;
            }
        }
        else
        {
            qDebug() << "Query execution failed:" << query.lastError();
        }
    }
}

Modele::UnEtat Modele::getEtat()
{
    return _etat;
}

void Modele::setEtat(UnEtat e)
{
    _etat = e;
}

QList<QString> Modele::avancer(int idImage)
{
    QSqlQuery query;

    query.exec("SELECT COUNT(idphoto) FROM Diapos");
    query.next();
    int count = query.value(0).toInt();

    if (idImage == count)
    {
        idImage = 1;
    }
    else
    {
        idImage += 1;
    }

    query.prepare("SELECT D.titrePhoto, F.nomFamille, D.uriPhoto "
                  "FROM Diapos D "
                  "JOIN Familles F ON D.idFam = F.idFamille "
                  "WHERE idphoto = ?;");
    query.bindValue(0, idImage);
    query.exec();
    query.next();

    QList<QString> liste;
    liste.append(query.value(0).toString());
    liste.append(query.value(1).toString());
    liste.append(query.value(2).toString());
    liste.append(QString::number(idImage));

    setEtat(UnEtat::change);

    return liste;
}

QList<QString> Modele::reculer(int idImage)
{
    QSqlQuery query;

        query.exec("SELECT COUNT(idphoto) FROM Diapos");
        query.next();
        int count = query.value(0).toInt();

        if (idImage == 1)
        {
            idImage = count;
        }
        else
        {
            idImage -= 1;
        }

        query.prepare("SELECT D.titrePhoto, F.nomFamille, D.uriPhoto "
                      "FROM Diapos D "
                      "JOIN Familles F ON D.idFam = F.idFamille "
                      "WHERE idphoto = ?;");
        query.bindValue(0, idImage);
        query.exec();
        query.next();

        QList<QString> liste;
        liste.append(query.value(0).toString());
        liste.append(query.value(1).toString());
        liste.append(query.value(2).toString());
        liste.append(QString::number(idImage));
        return liste;
}

void Modele::aProposDe()
{
    Dialog * maDlg= new Dialog(nullptr);
    maDlg->exec();
}

void Modele::quitter()
{
    QCoreApplication::quit();
}

QList<QString> Modele::enlever()
{
    QList<QString> liste;
    liste.append(QString::fromStdString("Titre de l'image"));
    liste.append(QString::fromStdString("Categorie"));
    liste.append(QString::fromStdString("Chemin d'acces"));
    liste.append(QString::fromStdString("nb images"));

    _etat = Modele::change;

    return liste;
}

int Modele::vitesseDefil()
{
    VitesseDefil * maVitDef= new VitesseDefil(nullptr);
    maVitDef->exec();
    return maVitDef->getVitesse();
}
