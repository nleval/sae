#include "lecteurvue.h"
#include "presentation.h"
#include "modele.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Modele *m = new Modele();
    LecteurVue w;
    Presentation *p = new Presentation();

    //Lier la vue et la presentation
    p->setVue(&w);
    w.setPresentation(p);

    // Lier la présentation et le modele
    p->setModele(m);

    w.majInterface(p->getModele()->getEtat());
    w.show();
    return a.exec();
}
