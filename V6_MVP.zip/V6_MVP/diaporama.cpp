#include "diaporama.h"
#include "QtSql/qsqlquery.h"
#include "qsqlquery.h"

Diaporama::Diaporama():id(0), titre(""), vitesseDefilement(0) {
    images.clear();
}

Diaporama::~Diaporama()
{
    vider();
}

unsigned int Diaporama::getId() const
{
    return id;
}

string Diaporama::getTitre() const
{
    return titre;
}

int Diaporama::getVitesseDefilement() const
{
    return vitesseDefilement;
}

ImagesDiaporama Diaporama::getImages() const
{
    return images;
}


unsigned int Diaporama::nbImages() const
{
    return images.size();
}

void Diaporama::setId(unsigned int pId)
{
    id = pId;
}

void Diaporama::setTitre(string pTitre)
{
    titre = pTitre;
}

void Diaporama::setVitesseDefilement(unsigned int pVitesseDefilement)
{
    vitesseDefilement = pVitesseDefilement;
}

void Diaporama::setImages(const ImagesDiaporama& pImages)
{
    images = pImages;
}

void Diaporama::ajouterImageEnFin(ImageDansDiaporama* pImage)
{
    images.push_back(pImage);

    // post-condition : nbImages() > 0
}

void Diaporama::enleverImageEnFin()
{
    if (nbImages() != 0)
    {
        images.pop_back();
    }

    // post-condition : nbImages() >= 0
}

void Diaporama::vider()
{
    unsigned int taille = nbImages();
    for (unsigned int i = 0; i < taille ; i++)
    {
        enleverImageEnFin(); /* Removes the last element in the vector,
                              effectively reducing the container size by one.
                              AND deletes the removed element */
    }
    // post-condition : nbImages() == 0
}

void Diaporama::charger()
{
    db = new Database();
    db->openDataBase();
    QSqlQuery query;

    /*ImageDansDiaporama* imageACharger;
    switch(id) {
      case 0 : // diaporama par défaut
        query.exec("SELECT d.idPhoto, f.nomFamille, d.titrePhoto, d.uriPhoto "
                                                                  "FROM Diapos d "
                                                                  "JOIN Familles f ON d.idFam=f.idFamille "
                                                                  "WHERE d.idPhoto = 1");
        imageACharger = new ImageDansDiaporama(query.value(0).toUInt(), query.value(1).toString(), query.value(2).toString(), query.value(3).toString());
        ajouterImageEnFin(imageACharger);
        break ;//
      case 1 : // diaporama de Pantxika
          imageACharger = new ImageDansDiaporama(3, "personnage", "Pinnochio", ":/Lecteur/cartesDisney/Disney_29.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(2, "personnage", "Blanche Neige", ":/Lecteur/cartesDisney/Disney_4.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(4, "personnage", "Alice", ":/Lecteur/cartesDisney/Disney_2.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(1, "animal", "Mickey", ":/Lecteur/cartesDisney/Disney_19.gif");
          ajouterImageEnFin(imageACharger);
          break ;//
      case 2 : // diaporama de Thierry
          imageACharger = new ImageDansDiaporama(1, "personnage", "Pinnochio", ":/Lecteur/cartesDisney/Disney_29.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(2, "personnage", "Blanche Neige", ":/Lecteur/cartesDisney/Disney_4.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(3, "personnage", "Alice", ":/Lecteur/cartesDisney/Disney_2.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(4, "animal", "Mickey", ":/Lecteur/cartesDisney/Disney_19.gif");
          ajouterImageEnFin(imageACharger);
          break ;//
      case 3 : // diaporama de Yann
          imageACharger = new ImageDansDiaporama(2, "personnage", "Pinnochio", ":/Lecteur/cartesDisney/Disney_29.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(1, "personnage", "Blanche Neige", ":/Lecteur/cartesDisney/Disney_4.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(4, "personnage", "Alice", ":/Lecteur/cartesDisney/Disney_2.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(3, "animal", "Mickey", ":/Lecteur/cartesDisney/Disney_19.gif");
          ajouterImageEnFin(imageACharger);
          break ;//
      case 4 : // diaporama de Manu
          imageACharger = new ImageDansDiaporama(4, "personnage", "Pinnochio", ":/Lecteur/cartesDisney/Disney_29.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(3, "personnage", "Blanche Neige", ":/Lecteur/cartesDisney/Disney_4.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(2, "personnage", "Alice", ":/Lecteur/cartesDisney/Disney_2.gif");
          ajouterImageEnFin(imageACharger);
          imageACharger = new ImageDansDiaporama(1, "animal", "Mickey", ":/Lecteur/cartesDisney/Disney_19.gif");
          ajouterImageEnFin(imageACharger);
          break ;//
      default : break;
        }*/
    db->closeDataBase();
}

void Diaporama::trierParRangCroissant()
{
    ImageDansDiaporama* pteurImage;
    unsigned int taille = nbImages();
    for (unsigned int ici = taille-1; ici >=1 ; ici--)
    {
        // faire monter la bulle ici = déplacer l'élément de rang le plus grand en position ici
        // par échanges successifs
        for (unsigned int i = 0; i < ici; i++)
        {
            if (images[i]->getRangDansDiaporama() > images[i+1]->getRangDansDiaporama())
            {
                // echanger les 2 éléments
                pteurImage = images[i];
                images[i] = images[i+1];
                images[i+1] = pteurImage;
            }
        }
    }
}

