#ifndef LECTEURVUE_H
#define LECTEURVUE_H

#include <QWidget>
#include <QMainWindow>
#include <QAction>
#include "modele.h"

QT_BEGIN_NAMESPACE
namespace Ui { class LecteurVue; }
QT_END_NAMESPACE

class Presentation;
class LecteurVue : public QMainWindow
{
    Q_OBJECT

public:
    LecteurVue(QWidget *parent = nullptr);
    ~LecteurVue();
    void majInterface(Modele::UnEtat e, QList<QString> l = QList<QString>());


    Presentation* getPresentation();
    void setPresentation(Presentation *p);

private:
    Ui::LecteurVue *ui;
    Presentation* _laPresentation;

private slots:
    void avancer();
    void reculer();
    void quitter();
    void lancerDiapo();
    void arreterDiapo();
    void aProposDe();
    void chargerDiapo();
    void enleverDiapo();
    void vitesseDefilement();
};
#endif // LECTEURVUE_H
