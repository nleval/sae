#include "lecteurvue.h"
#include "ui_lecteurvue.h"
#include <QDebug>
#include "presentation.h"

LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{
    ui->setupUi(this);
    //ui->etNbImage(NbImage());
    //ui->etTitreDiapo(getTitre());

    connect(ui->bAvancer, SIGNAL(clicked()), this, SLOT(avancer()));
    connect(ui->bReculer, SIGNAL(clicked()), this, SLOT(reculer()));
    connect(ui->actionQuitter, SIGNAL(triggered()), this, SLOT(quitter()));
    connect(ui->bLancerDiapo, SIGNAL(clicked()), this, SLOT(lancerDiapo()));
    connect(ui->bArretDiapo, SIGNAL(clicked()), this, SLOT(arreterDiapo()));
    connect(ui->actionA_propos_de, SIGNAL(triggered()), this, SLOT(aProposDe()));
    connect(ui->actionCharger_diaporama, SIGNAL(triggered()), this, SLOT(chargerDiapo()));
    connect(ui->actionEnlever_diaporama, SIGNAL(triggered()), this, SLOT(EnleverDiapo()));
    connect(ui->actionVitesse_de_defilement, SIGNAL(triggered()), this, SLOT(vitesseDefilement()));
    connect(ui->actionManu, SIGNAL(triggered()), this, SLOT (diapoManu()));
    connect(ui->actionPantxika, SIGNAL(triggered()), this, SLOT (diapoPantxika()));
    connect(ui->actionThierry, SIGNAL(triggered()), this, SLOT (diapoThierry()));
    connect(ui->actionYann, SIGNAL(triggered()), this, SLOT (diapoYann()));
}

LecteurVue::~LecteurVue()
{
    delete ui;
}

void LecteurVue::majInterface(Modele::UnEtat e, QList<QString> l)
{
    switch(e)
    {
        case Modele::change :
        {
            ui->etIntituleImage->setText(l[0]);
            ui->etFiltreType->setText(l[1]);
            ui->etTitreDiapo->setText(l[2]);
            ui->etImage->setText(l[3]);
            //titre diapo en l[4]
        }
        case Modele::vide :
        {

        }
    }
}

Presentation *LecteurVue::getPresentation()
{
    return _laPresentation;
}

void LecteurVue::setPresentation(Presentation *p)
{
    _laPresentation = p;
}

void LecteurVue::avancer()
{
    getPresentation()->demanderAvancer();
}

void LecteurVue::reculer()
{
    getPresentation()->demanderReculer();
}

void LecteurVue::quitter()
{
    getPresentation()->demanderQuitter();
}

void LecteurVue::lancerDiapo()
{
    getPresentation()->demanderLancerDiapo();
}

void LecteurVue::arreterDiapo()
{
    getPresentation()->demanderArreterDiapo();
}

void LecteurVue::aProposDe()
{
    getPresentation()->demanderAProposDe();
}

void LecteurVue::chargerDiapo()
{
    getPresentation()->demanderChargerDiapo();
}

void LecteurVue::enleverDiapo()
{
    getPresentation()->demanderEnleverDiapo();
}

void LecteurVue::vitesseDefilement()
{
    getPresentation()->demanderVitesseDefilement();
}

void LecteurVue::diapoPantxika()
{
    getPresentation()->demanderDiapoPantxika();
}

void LecteurVue::diapoManu()
{
    getPresentation()->demanderDiapoManu();
}

void LecteurVue::diapoYann()
{
    getPresentation()->demanderDiapoYann();
}

void LecteurVue::diapoThierry()
{
    getPresentation()->demanderDiapoThierry();
}


