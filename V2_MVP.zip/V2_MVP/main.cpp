#include "lecteurvue.h"
#include "presentation.h"
#include "modele.h"
#include "imagedansdiaporama.h"
#include <QApplication>

struct InfosDiaporama {
    unsigned int id;    // identifiant du diaporama dans la BD
    string titre;       // titre du diaporama
    unsigned int vitesseDefilement;
};
typedef vector<InfosDiaporama> Diaporamas;

void charger (Diaporamas& pDiaporamas);
/* Chargement du tableau des infos sur diaporamas avec des diaporamas préalablement construits 'en dur'.
   Dans une version ultérieure, le diaporama courant affiché par le Lecteur de diaporamas sera chargé à partir
   d'une base de données.
*/

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Diaporamas diaporamas;
    charger(diaporamas);

    //création du modèle
    Modele *m = new Modele();
    //création de la présentation
    Presentation *p = new Presentation();
    //création de la vue
    LecteurVue w;
    //faire pointer la présentation vers la vue et le modèle
    p->setVue(&w);
    p->setModele(m);
    //faire pointer la vue vers la présentation
    w.setPresentation(p);
    //initialiser la vue en conformité avec l'état initial du modèle
    w.majInterface(m->getMode(), m->getAction());

    //aficher la vue et démarrer la boucle d'attente des messages
    w.show();
    return a.exec();
}

void charger(Diaporamas& pDiaporamas)
{
    InfosDiaporama infosACharger;
    // Diaporama de Pantxika
    infosACharger.id = 1;
    infosACharger.titre = "Diaporama Pantxika";
    infosACharger.vitesseDefilement = 2;
    pDiaporamas.push_back(infosACharger);

    // Diaporama de Thierry
    infosACharger.id = 2;
    infosACharger.titre = "Diaporama Thierry";
    infosACharger.vitesseDefilement = 4;
    pDiaporamas.push_back(infosACharger);

    // Diaporama de Yann
    infosACharger.id = 3;
    infosACharger.titre = "Diaporama Yann";
    infosACharger.vitesseDefilement = 2;
    pDiaporamas.push_back(infosACharger);

    // Diaporama de Manu
    infosACharger.id = 4;
    infosACharger.titre = "Diaporama Manu";
    infosACharger.vitesseDefilement = 1;
    pDiaporamas.push_back(infosACharger);

}
