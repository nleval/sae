#include "presentation.h"
#include <QDebug>
#include "lecteurvue.h"
#include <QString>
#include <QList>

Presentation::Presentation(QObject *parent) :
    QObject{parent},
    idDiapo(0),
    idImage(0)
{

    InfosDiaporama infosACharger;

    // Diaporama de Pantxika
    infosACharger.id = 1;
    infosACharger.titre = "Diaporama Pantxika";
    infosACharger.vitesseDefilement = 2;
    pDiaporamas.push_back(infosACharger);

     // Diaporama de Thierry
    infosACharger.id = 2;
    infosACharger.titre = "Diaporama Thierry";
    infosACharger.vitesseDefilement = 4;
    pDiaporamas.push_back(infosACharger);

     // Diaporama de Yann
    infosACharger.id = 3;
    infosACharger.titre = "Diaporama Yann";
    infosACharger.vitesseDefilement = 2;
    pDiaporamas.push_back(infosACharger);

     // Diaporama de Manu
    infosACharger.id = 4;
    infosACharger.titre = "Diaporama Manu";
    infosACharger.vitesseDefilement = 1;
    pDiaporamas.push_back(infosACharger);
}

Modele *Presentation::getModele()
{
    return _leModele;
}

LecteurVue *Presentation::getVue()
{
    return _laVue;
}

int Presentation::getIdDiapo()
{
    return idDiapo;
}

int Presentation::getIdImage()
{
    return idImage;
}

void Presentation::setModele(Modele *m)
{
    _leModele = m;
}

void Presentation::setVue(LecteurVue *v)
{
    _laVue = v;
}

void Presentation::setIdDiapo(unsigned int i)
{
    idDiapo = i;
}

void Presentation::setIdImage(unsigned int i)
{
    idImage = i;
}

//-------------------------------------------

void Presentation::demanderAvancer()
{
    QList<QString> liste;

    liste = _leModele->avancer(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo - 1].titre));
    idImage = QString(liste[3]).toInt();
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderReculer()
{
    QList<QString> liste;

    liste = _leModele->reculer(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo - 1].titre));
    idImage = QString(liste[3]).toInt();
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderQuitter()
{
    _leModele->quitter();
}

void Presentation::demanderLancerDiapo()
{
    //plus tard
}

void Presentation::demanderArreterDiapo()
{
    //plus tard
}

void Presentation::demanderAProposDe()
{
    _laVue->hide();
    _leModele->aProposDe();
    _laVue->majInterface(_leModele->getEtat());
    _laVue->show();
}

void Presentation::demanderChargerDiapo()
{
    //Mais qu'est ce donc
}

void Presentation::demanderEnleverDiapo()
{
    //juste clear
}

void Presentation::demanderVitesseDefilement()
{
    //plus tard
}

void Presentation::demanderDiapoPantxika()
{
    idDiapo = 1;
    idImage = 1;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo - 1].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderDiapoThierry()
{
    idDiapo = 2;
    idImage = 1;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo - 1].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderDiapoYann()
{
    idDiapo = 3;
    idImage = 1;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo - 1].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}

void Presentation::demanderDiapoManu()
{
    idDiapo = 4;
    idImage = 1;
    QList<QString> liste;

    liste = _leModele->changerDiapo(idDiapo, idImage);
    liste.append(QString::fromStdString(pDiaporamas[idDiapo - 1].titre));
    getVue()->majInterface(getModele()->getEtat(), liste);
}
