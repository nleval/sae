#include "modele.h"
#include <QString>
#include "dialog.h"
#include <QCoreApplication>

Modele::Modele(QObject *parent)
    : QObject{parent}
{}

Modele::UnEtat Modele::getEtat()
{
    return _etat;
}

Diaporama Modele::getDiapo()
{
    return diapo;
}

void Modele::setDiapo(Diaporama d)
{
    diapo = d;
}

QList<QString> Modele::avancer(unsigned int idDiapo, unsigned int idImage)
{
    diapo.setId(idDiapo);
    diapo.charger();

    if (idImage == diapo.nbImages() - 1)
    {
        idImage = 0;
    }
    else
    {
        idImage += 1;
    }

    QList<QString> liste;
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getTitre()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getCategorie()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getChemin()));
    liste.append(QString::number(idImage));
    liste.append(QString::fromStdString(diapo.getTitre()));

    _etat = Modele::change;

    return liste;
}

QList<QString> Modele::reculer(unsigned int idDiapo, unsigned int idImage)
{
    diapo.setId(idDiapo);
    diapo.charger();
    if (idImage == 0)
    {
        idImage = diapo.nbImages() - 1;
    }
    else
    {
        idImage -= 1;
    }
    QList<QString> liste;
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getTitre()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getCategorie()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage]->getChemin()));
    liste.append(QString::number(idImage));
    liste.append(QString::fromStdString(diapo.getTitre()));

    _etat = Modele::change;

    return liste;
}

void Modele::aProposDe()
{
    Dialog * maDlg= new Dialog(nullptr);
    maDlg->exec();
}

void Modele::quitter()
{
    QCoreApplication::quit();
}

QList<QString> Modele::changerDiapo(unsigned int idDiapo, unsigned int idImage)
{
    diapo.setId(idDiapo);
    diapo.charger();

    QList<QString> liste;
    liste.append(QString::fromStdString(diapo.getImages()[idImage - 1]->getTitre()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage - 1]->getCategorie()));
    liste.append(QString::fromStdString(diapo.getImages()[idImage - 1]->getChemin()));
    liste.append(QString::number(idImage));

    _etat = Modele::change;

    return liste;
}
