#ifndef MODELE_H
#define MODELE_H

#include <QObject>
#include "diaporama.h"
#include "imageDansDiaporama.h"

class Modele : public QObject
{
    Q_OBJECT
public:
    enum UnEtat {vide, change};
    explicit Modele(QObject *parent = nullptr);
    UnEtat getEtat();
    Diaporama getDiapo();

    void setDiapo(Diaporama);

    QList<QString> avancer(unsigned int, unsigned int);
    QList<QString> reculer(unsigned int, unsigned int);
    void aProposDe();
    void quitter();
    QList<QString> changerDiapo(unsigned int, unsigned int);

private:
    UnEtat _etat;
    Diaporama diapo;

signals:
};

#endif // MODELE_H
