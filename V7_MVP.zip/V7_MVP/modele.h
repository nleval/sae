#ifndef MODELE_H
#define MODELE_H

#include <QObject>
#include "database.h"

class Modele : public QObject
{
    Q_OBJECT
public:
    enum UnEtat {vide, change};
    explicit Modele(QObject *parent = nullptr);
    UnEtat getEtat();
    void setEtat(UnEtat);

    QList<QString> avancer(int, int);
    QList<QString> reculer(int, int);
    void aProposDe();
    void quitter();
    QList<QString> changerDiapo(int, int);
    QList<QString> enlever();
    int vitesseDefil();
    int recupVitesse(int);

private:
    UnEtat _etat;
    Database *db;

signals:
};

#endif // MODELE_H
