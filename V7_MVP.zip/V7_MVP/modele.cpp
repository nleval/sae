#include "modele.h"
#include <QString>
#include "QtSql/qsqlquery.h"
#include "dialog.h"
#include <QCoreApplication>
#include "qsqlerror.h"
#include "vitessedefil.h"
#include "database.h"
#include "qsqlquery.h"

Modele::Modele(QObject *parent)
    : QObject{parent}
{
    db = new Database();
    db->openDataBase();
}

Modele::UnEtat Modele::getEtat()
{
    return _etat;
}

void Modele::setEtat(UnEtat e)
{
    _etat = e;
}

QList<QString> Modele::avancer(int idDiapo, int idImage)
{
    QSqlQuery query;

    query.prepare("SELECT COUNT(idDiapo) "
                  "FROM DiaposDansDiaporama "
                  "WHERE idDiaporama = ?;");
    query.bindValue(0, idDiapo);
    query.exec();
    query.next();
    int count = query.value(0).toInt();

    if (idImage == count)
    {
        idImage = 1;
    }
    else
    {
        idImage += 1;
    }

    query.prepare("SELECT D.titrePhoto, F.nomFamille, D.uriPhoto, Di.titreDiaporama, DD.idDiapo "
                  "FROM Diapos D "
                  "JOIN Familles F ON D.idFam = F.idFamille "
                  "JOIN DiaposDansDiaporama DD ON D.idPhoto = DD.idDiapo "
                  "JOIN Diaporamas Di ON DD.idDiaporama = Di.idDiaporama "
                  "WHERE Di.idDiaporama = ? "
                  "ORDER BY DD.idDiapo;");
    query.bindValue(0, idDiapo);
    query.exec();

    for(int i = 0; i < idImage; i++)
    {
        query.next();
    }

    QList<QString> liste;
    liste.append(query.value(0).toString());
    liste.append(query.value(1).toString());
    liste.append(query.value(2).toString());
    liste.append(QString::number(idImage));
    liste.append(query.value(3).toString());

    setEtat(UnEtat::change);

    return liste;
}

QList<QString> Modele::reculer(int idDiapo, int idImage)
{
    QSqlQuery query;

        query.prepare("SELECT COUNT(idDiapo) "
                      "FROM DiaposDansDiaporama "
                      "WHERE idDiaporama = ?;");
        query.bindValue(0, idDiapo);
        query.exec();
        query.next();
        int count = query.value(0).toInt();

        if (idImage == 1)
        {
            idImage = count;
        }
        else
        {
            idImage -= 1;
        }

        query.prepare("SELECT D.titrePhoto, F.nomFamille, D.uriPhoto, Di.titreDiaporama, DD.idDiapo "
                          "FROM Diapos D "
                          "JOIN Familles F ON D.idFam = F.idFamille "
                          "JOIN DiaposDansDiaporama DD ON D.idPhoto = DD.idDiapo "
                          "JOIN Diaporamas Di ON DD.idDiaporama = Di.idDiaporama "
                          "WHERE Di.idDiaporama = ? "
                          "ORDER BY DD.idDiapo;");
        query.bindValue(0, idDiapo);
        query.exec();

        for(int i = 0; i < idImage; i++)
        {
            query.next();
        }

        QList<QString> liste;
        liste.append(query.value(0).toString());
        liste.append(query.value(1).toString());
        liste.append(query.value(2).toString());
        liste.append(QString::number(idImage));
        liste.append(query.value(3).toString());
        return liste;
}

void Modele::aProposDe()
{
    Dialog * maDlg= new Dialog(nullptr);
    maDlg->exec();
}

void Modele::quitter()
{
    QCoreApplication::quit();
}

QList<QString> Modele::changerDiapo(int idDiapo, int idImage)
{
    QSqlQuery query;

    query.prepare("SELECT D.titrePhoto, F.nomFamille, D.uriPhoto, Di.titreDiaporama, DD.idDiapo "
                  "FROM Diapos D "
                  "JOIN Familles F ON D.idFam = F.idFamille "
                  "JOIN DiaposDansDiaporama DD ON D.idPhoto = DD.idDiapo "
                  "JOIN Diaporamas Di ON DD.idDiaporama = Di.idDiaporama "
                  "WHERE Di.idDiaporama = ? "
                  "ORDER BY DD.idDiapo;");
    query.bindValue(0, idDiapo);
    query.exec();

     for(int i = 0; i < idImage; i++)
     {
        query.next();
     }

    QList<QString> liste;
    liste.append(query.value(0).toString());
    liste.append(query.value(1).toString());
    liste.append(query.value(2).toString());
    liste.append(QString::number(idImage));
    liste.append(query.value(3).toString());

    setEtat(UnEtat::change);

    return liste;
}

QList<QString> Modele::enlever()
{
    QList<QString> liste;
    liste.append(QString::fromStdString("Titre de l'image"));
    liste.append(QString::fromStdString("Categorie"));
    liste.append(QString::fromStdString("Chemin d'acces"));
    liste.append(QString::fromStdString("nb images"));

    _etat = Modele::change;

    return liste;
}

int Modele::vitesseDefil()
{
    VitesseDefil * maVitDef= new VitesseDefil(nullptr);
    maVitDef->exec();
    return maVitDef->getVitesse();
}

int Modele::recupVitesse(int idDiapo)
{
    QSqlQuery query;

        query.prepare("SELECT vitesseDefilement "
                      "FROM Diaporamas "
                      "WHERE idDiaporama = ?;");
        query.bindValue(0, idDiapo);
        query.exec();
        query.next();

        int vitesse = query.value(0).toInt();

        return vitesse;
}
