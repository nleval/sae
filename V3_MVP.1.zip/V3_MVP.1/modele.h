#ifndef MODELE_H
#define MODELE_H
#include "diaporama.h"
#include <QObject>

class Modele : public QObject
{
    Q_OBJECT
public:
    enum UnMode {manuel, automatique};
    Q_ENUM(UnMode)
    enum UneAction {avance, recule, lanceD, arreteD, changeD, enleveD, vitesseDefil};
    Q_ENUM(UneAction)
    explicit Modele(UnMode u=manuel, QObject *parent = nullptr);
    UnMode getMode();
    UneAction getAction();
    void setMode(UnMode m);
    void setAction(UneAction a);
    bool lecteurVide() const;                         // = vrai si aucun diaporama associé au lecteur, faux Sinon
    unsigned int getIdDiaporama() const;
    Diaporama* getDiaporama() const;
    unsigned int getPosImageCourante() const;
    ImageDansDiaporama* getImageCourante() const;     // retourne le pointeur vers l'image courante
    unsigned int nbImages() const;                    // taille de la collection pointée par diaporama
    void afficher();            // affiche les informations sur lecteur + éventuellement diaporama et image courante

    void setIdDiaporama(unsigned int pIdDiaporama);
    void setDiaporama (Diaporama* pDiaporama);
    void setPosImageCourante(unsigned int pPosImageCourante);

    void aProposDe();
    void quitter();

    void avancer();
    void reculer();
    void lancerDiapo();
    void arreterDiapo();
    void changerDiapo();
    void enleverDiapo();
    void vitesseDefilement();

private:
    UnMode _mode;
    UneAction _action;
    unsigned idDiaporama;             /* identifiant en Base de Données du diaporama courant,
                                         = 0 si pas de diaporama dans le lecteur */
    Diaporama* diaporama;             /* pointeur vers le diaporama associé au lecteur,
                                         = nullptr si pas de diaporama dans le lecteur) */
    unsigned int posImageCourante;    /* position de l'image courante du diaporama courant.
                                         Indéfinie quand lecteur vide ou diaporama vide.
                                         >= 0 quand lecteur non vide et diaporama non vide */

};

#endif // MODELE_H
