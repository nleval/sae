#ifndef DIALOGCHANGER_H
#define DIALOGCHANGER_H

#include <QDialog>

namespace Ui {
class DialogChanger;
}

class DialogChanger : public QDialog
{
    Q_OBJECT

public:
    explicit DialogChanger(QWidget *parent = nullptr);
    ~DialogChanger();

private:
    Ui::DialogChanger *ui;

public slots:
    int entrerDiapo();
};

#endif // DIALOGCHANGER_H
