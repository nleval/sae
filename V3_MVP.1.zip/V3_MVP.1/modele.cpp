#include "modele.h"
#include <QDebug>
#include "dialog.h"
#include "dialogchanger.h"
#include <QCoreApplication>

Modele::Modele(UnMode u, QObject *parent)
    : QObject{parent}, _mode(u)
{
    _mode = UnMode::manuel;
}

Modele::UnMode Modele::getMode()
{
    return _mode;
}

Modele::UneAction Modele::getAction()
{
    return _action;
}

void Modele::setMode(UnMode m)
{
    _mode = m;
}

void Modele::setAction(UneAction a)
{
    _action = a;
}

bool Modele::lecteurVide() const
{
    return (getDiaporama() == nullptr);
}

unsigned int Modele::getIdDiaporama() const
{
    return idDiaporama; // valeur >= 0
}

Diaporama* Modele::getDiaporama() const
{
    return diaporama;   // peut être nullptr
}

unsigned int Modele::getPosImageCourante() const
{
    if (lecteurVide() ||
        (!lecteurVide() && nbImages() == 0 ))
    {
        throw string ("pas d'image courante : lecteur vide ou diaporama vide");
    }
    return posImageCourante;
}

ImageDansDiaporama *Modele::getImageCourante() const
{
    if (lecteurVide() ||
        (!lecteurVide() && nbImages() == 0 ))
    {
        return nullptr;
    }

    return diaporama->getImages().at(getPosImageCourante());
}


unsigned int Modele::nbImages() const
{
    if (lecteurVide())
    {
        throw string ("lecteur vide");
    }
    return diaporama->nbImages();
}

void Modele::afficher()
{
    /* affichen selon le cas :
     * - lecteur vide
     * ou bien
     * - le numéro de diaporama affiché
     * - et l'image courante ou bien 'diaporama vide' */

    string info;
    if (lecteurVide())
    {
        info = "Lecteur vide = pas de diaporama charge ";
    }

    else
    {
        info = "Diaporama num. " + std::to_string(getIdDiaporama()) + " - "  + getDiaporama()->getTitre() + "\n";

        // Afficher l'image courante du diaporama chargé
        if (nbImages() == 0)
        {
            info.append("Diaporama vide \n");
        }
        else
        {
            info.append(std::to_string(diaporama->getImages()[posImageCourante]->getRangDansDiaporama()));
            info.append(" sur ");
            info.append((std::to_string(diaporama->getImages().size())));
            info.append(" / ");
            diaporama->getImages()[posImageCourante]->afficher();
        }
    }
}

void Modele::setIdDiaporama(unsigned int pIdDiaporama)
{
    idDiaporama = pIdDiaporama;
}

void Modele::setDiaporama(Diaporama* pDiaporama)
{
    diaporama = pDiaporama;
}

void Modele::setPosImageCourante(unsigned int pPosImageCourante)
{
    posImageCourante = pPosImageCourante;
}

void Modele::avancer()
{
    qDebug() << "bouton avancer cliqué";
    if (!lecteurVide())
    {
        if (getPosImageCourante() == nbImages()- 1)
        {
            setPosImageCourante(0);
        }
        else {
            setPosImageCourante(getPosImageCourante() + 1);
        }
    }
    setMode(manuel);
    setAction(avance);
}

void Modele::reculer()
{
    qDebug() << "bouton reculer cliqué";
    if (!lecteurVide())
    {
        if (getPosImageCourante() == 0)
        {
            setPosImageCourante(nbImages()- 1);
        }
        else {
            setPosImageCourante(getPosImageCourante() - 1);
        }
    }
    setMode(manuel);
    setAction(recule);
}

void Modele::quitter()
{
    qDebug() << "bouton quitter cliqué";
    QCoreApplication::quit();
}

void Modele::lancerDiapo()
{
    qDebug() << "bouton Lancer diaporama cliqué";
    setMode(automatique);
    setAction(lanceD);
}

void Modele::arreterDiapo()
{
    qDebug() << "bouton du menu Arrêter diaporama cliqué";
    setMode(manuel);
    setAction(arreteD);
}

void Modele::aProposDe()
{
    qDebug() << "bouton du menu A propos de cliqué";
    Dialog * maDlg= new Dialog(nullptr);
    maDlg->exec();
}

void Modele::changerDiapo()
{
    qDebug() << "bouton du menu changer de diaporama cliqué";
    /*
    if (pId != 0)
    {
        if (!lecteurVide())
        {
            diaporama->vider();
        }
        else
        {
            diaporama = new Diaporama();
        }
        setIdDiaporama(pId);
        diaporama->setId(pId);
        diaporama->setTitre(pTitre);
        diaporama->setVitesseDefilement(pVitesse);
        chargerDiapo(); // charge les images et la position de l'image courante
    }
    else
        if (!lecteurVide())
        {
            enleverDiapo();
        }
    setMode(manuel);
    setAction(changeD);
    */

    DialogChanger *maDlg = new DialogChanger(nullptr);
    maDlg->exec();
    idDiaporama = maDlg->entrerDiapo();
    setAction(changeD);
}

/*
void Modele::chargerDiapo()
{
    qDebug() << "bouton du menu charger un diaporama cliqué";
    diaporama->charger();
    if (nbImages() != 0)
    { setPosImageCourante(0) ;}
    setMode(manuel);
    setAction(chargeD);
}
*/

void Modele::enleverDiapo()
{
    qDebug() << "bouton du menu enlever le diaporama cliqué";
    if (!lecteurVide())
    {
        diaporama->vider();
        setDiaporama(nullptr);
        setIdDiaporama(0);
    }
    setMode(manuel);
    setAction(enleveD);
}

void Modele::vitesseDefilement()
{
    qDebug() << "bouton du menu vitesse de défilement cliqué";
    setMode(automatique);
    setAction(vitesseDefil);
}
