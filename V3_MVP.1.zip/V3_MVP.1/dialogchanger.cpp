#include "dialogchanger.h"
#include "ui_dialogchanger.h"

DialogChanger::DialogChanger(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogChanger)
{
    ui->setupUi(this);
    connect(ui->lineEdit, SIGNAL(triggered()), this, SLOT(entrerDiapo()));
}

DialogChanger::~DialogChanger()
{
    delete ui;
}

int DialogChanger::entrerDiapo()
{
    return ui->lineEdit->text().toInt();
}
